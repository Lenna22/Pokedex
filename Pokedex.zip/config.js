module.exports = {
  PORT: 5000,
  //APPID
  ID: 2814670,
  };
